---
tags: [log]
---
# 2026-01-25

Sky: windy but clear. With [[Dark site]].

Seen: [[Algol]], [[Aquila]].
