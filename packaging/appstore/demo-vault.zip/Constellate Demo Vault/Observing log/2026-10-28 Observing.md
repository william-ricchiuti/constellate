---
tags: [log]
---
# 2026-10-28

Sky: windy but clear. With [[Dark site]].

Seen: [[Lyra]], [[Ursa Minor]], [[Orion Nebula]].
