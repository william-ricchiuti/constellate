---
tags: [log]
---
# 2026-11-15

Sky: clear. With [[Binoculars]], [[Telescope]].

Seen: [[Saturn]], [[Aquila]].
