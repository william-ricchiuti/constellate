---
tags: [log]
---
# 2026-07-03

Sky: thin cloud later. With [[Star chart]], [[Binoculars]].

Seen: [[Taurus]], [[Mars]], [[Alpha Centauri]], [[Leo]].
