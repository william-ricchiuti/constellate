---
tags: [log]
---
# 2026-02-13

Sky: moonlit. With [[Red flashlight]].

Seen: [[Ursa Minor]], [[Dubhe]].
