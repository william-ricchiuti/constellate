---
tags: [log]
---
# 2026-02-26

Sky: thin cloud later. With [[Red flashlight]].

Seen: [[Mercury]], [[Castor]], [[Canis Major]], [[Andromeda Galaxy]].
