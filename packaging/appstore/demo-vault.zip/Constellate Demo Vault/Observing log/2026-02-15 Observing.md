---
tags: [log]
---
# 2026-02-15

Sky: hazy. With [[Star chart]], [[Dark site]].

Seen: [[Venus]], [[Boötes]], [[Orion Nebula]], [[Jupiter]].
