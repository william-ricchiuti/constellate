---
tags: [log]
---
# 2026-02-08

Sky: moonlit. With [[Dark site]].

Seen: [[Ursa Minor]], [[Aquila]], [[Regulus]], [[Ring Nebula]].
