---
tags: [log]
---
# 2026-08-27

Sky: clear. With [[Telescope]], [[Dark site]].

Seen: [[Leo]], [[Mercury]], [[Pleiades]].
