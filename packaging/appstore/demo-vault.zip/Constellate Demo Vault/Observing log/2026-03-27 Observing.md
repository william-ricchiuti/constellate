---
tags: [log]
---
# 2026-03-27

Sky: windy but clear. With [[Star chart]], [[Dark site]].

Seen: [[Sagittarius]], [[Merak]].
