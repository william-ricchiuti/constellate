---
tags: [log]
---
# 2026-11-08

Sky: thin cloud later. With [[Red flashlight]], [[Dark site]].

Seen: [[Taurus]], [[Perseus]], [[Dubhe]], [[Jupiter]].
