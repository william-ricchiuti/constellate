---
tags: [log]
---
# 2026-08-12

Sky: clear. With [[Red flashlight]], [[Dark site]].

Seen: [[Perseus]], [[Sirius]].
