---
tags: [log]
---
# 2026-02-02

Sky: thin cloud later. With [[Star chart]].

Seen: [[Dubhe]], [[Algol]], [[Polaris]].
