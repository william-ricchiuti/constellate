---
tags: [log]
---
# 2026-08-24

Sky: windy but clear. With [[Telescope]], [[Red flashlight]].

Seen: [[Mars]], [[Double Cluster]].
