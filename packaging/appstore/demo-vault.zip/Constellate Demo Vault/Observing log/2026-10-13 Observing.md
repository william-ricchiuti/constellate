---
tags: [log]
---
# 2026-10-13

Sky: windy but clear. With [[Red flashlight]].

Seen: [[Pollux]], [[Arcturus]], [[Alpha Centauri]], [[Betelgeuse]].
