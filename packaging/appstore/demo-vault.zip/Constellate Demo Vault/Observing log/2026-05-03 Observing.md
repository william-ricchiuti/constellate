---
tags: [log]
---
# 2026-05-03

Sky: clear and cold. With [[Binoculars]].

Seen: [[Cassiopeia]], [[Centaurus]], [[Jupiter]].
