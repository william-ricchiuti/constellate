---
tags: [log]
---
# 2026-09-04

Sky: thin cloud later. With [[Binoculars]].

Seen: [[Aldebaran]], [[Algol]].
