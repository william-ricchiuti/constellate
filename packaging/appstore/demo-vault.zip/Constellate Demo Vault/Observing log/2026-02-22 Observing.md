---
tags: [log]
---
# 2026-02-22

Sky: windy but clear. With [[Binoculars]].

Seen: [[Gemini]], [[Boötes]].
