---
tags: [log]
---
# 2026-05-17

Sky: moonlit. With [[Star chart]].

Seen: [[Gemini]], [[Sagittarius]], [[Merak]].
