---
tags: [log]
---
# 2026-07-25

Sky: clear and cold. With [[Binoculars]], [[Telescope]].

Seen: [[Castor]], [[Lyra]], [[Altair]].
