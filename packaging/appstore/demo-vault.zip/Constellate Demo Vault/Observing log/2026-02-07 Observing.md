---
tags: [log]
---
# 2026-02-07

Sky: clear. With [[Dark site]], [[Telescope]].

Seen: [[Orion]], [[Altair]].
