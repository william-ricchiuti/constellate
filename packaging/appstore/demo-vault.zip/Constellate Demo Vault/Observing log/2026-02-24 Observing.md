---
tags: [log]
---
# 2026-02-24

Sky: clear. With [[Star chart]], [[Binoculars]].

Seen: [[Moon]], [[Uranus]], [[Andromeda Galaxy]].
