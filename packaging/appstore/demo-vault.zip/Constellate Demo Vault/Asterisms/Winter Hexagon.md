---
tags: [asterism]
---
# Winter Hexagon

A ring of bright winter stars.

[[Sirius]], [[Rigel]], [[Aldebaran]], [[Pollux]], [[Castor]]
