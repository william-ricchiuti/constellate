---
tags: [asterism]
---
# Big Dipper

Part of Ursa Major, and the way to Polaris.

[[Dubhe]], [[Merak]]
