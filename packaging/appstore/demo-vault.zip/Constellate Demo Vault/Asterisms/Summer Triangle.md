---
tags: [asterism]
---
# Summer Triangle

Three bright stars from three constellations.

[[Vega]], [[Deneb]], [[Altair]]
