---
tags: [hub]
---
# Sky atlas

- [[Orion]]
- [[Ursa Major]]
- [[Ursa Minor]]
- [[Cassiopeia]]
- [[Cygnus]]
- [[Lyra]]
- [[Aquila]]
- [[Scorpius]]
- [[Sagittarius]]
- [[Taurus]]
- [[Gemini]]
- [[Leo]]
- [[Andromeda]]
- [[Perseus]]
- [[Canis Major]]
- [[Boötes]]
- [[Crux]]
- [[Centaurus]]

By season: [[Winter sky]], [[Spring sky]], [[Summer sky]], [[Autumn sky]]

Shapes that aren't constellations: [[Summer Triangle]], [[Big Dipper]], [[Winter Hexagon]]
