---
tags: [constellation]
---
# Cassiopeia

A W of stars opposite the Big Dipper across the pole.

Bright stars: [[Schedar]]

Best in the [[Autumn sky]].

Back to the [[Sky atlas]].
