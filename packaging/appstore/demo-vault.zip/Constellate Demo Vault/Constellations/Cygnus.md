---
tags: [constellation]
---
# Cygnus

The swan, flying down the Milky Way.

Bright stars: [[Deneb]]

Best in the [[Summer sky]].

Back to the [[Sky atlas]].
