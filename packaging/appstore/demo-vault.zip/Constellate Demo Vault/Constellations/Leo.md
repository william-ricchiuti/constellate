---
tags: [constellation]
---
# Leo

The lion, a backwards question mark for a head.

Bright stars: [[Regulus]]

Best in the [[Spring sky]].

Back to the [[Sky atlas]].
