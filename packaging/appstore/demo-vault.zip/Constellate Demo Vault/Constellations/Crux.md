---
tags: [constellation]
---
# Crux

The Southern Cross, the smallest constellation.

Bright stars: [[Acrux]]

Back to the [[Sky atlas]].
