---
tags: [constellation]
---
# Ursa Major

The great bear; seven of its stars are the Big Dipper.

Bright stars: [[Dubhe]], [[Merak]]

Best in the [[Spring sky]].

Back to the [[Sky atlas]].
