---
tags: [constellation]
---
# Aquila

The eagle, holding Altair.

Bright stars: [[Altair]]

Best in the [[Summer sky]].

Back to the [[Sky atlas]].
