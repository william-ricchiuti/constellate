---
tags: [constellation]
---
# Taurus

The bull, with the Pleiades on its shoulder.

Bright stars: [[Aldebaran]]

Worth finding: [[Pleiades]]

Best in the [[Winter sky]].

Back to the [[Sky atlas]].
