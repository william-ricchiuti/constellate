---
tags: [constellation]
---
# Sagittarius

The archer; the centre of the galaxy lies behind it.

Worth finding: [[Lagoon Nebula]]

Best in the [[Summer sky]].

Back to the [[Sky atlas]].
