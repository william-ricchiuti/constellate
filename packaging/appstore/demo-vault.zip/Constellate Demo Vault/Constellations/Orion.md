---
tags: [constellation]
---
# Orion

The hunter, the easiest winter constellation to find.

Bright stars: [[Betelgeuse]], [[Rigel]]

Worth finding: [[Orion Nebula]]

Best in the [[Winter sky]].

Back to the [[Sky atlas]].
