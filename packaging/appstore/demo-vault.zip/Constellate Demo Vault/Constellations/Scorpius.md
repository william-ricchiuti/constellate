---
tags: [constellation]
---
# Scorpius

A curling scorpion low in the summer south.

Bright stars: [[Antares]]

Best in the [[Summer sky]].

Back to the [[Sky atlas]].
