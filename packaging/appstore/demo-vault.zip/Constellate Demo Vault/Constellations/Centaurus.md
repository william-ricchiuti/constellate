---
tags: [constellation]
---
# Centaurus

The centaur, wrapped around the Southern Cross.

Bright stars: [[Alpha Centauri]]

Back to the [[Sky atlas]].
