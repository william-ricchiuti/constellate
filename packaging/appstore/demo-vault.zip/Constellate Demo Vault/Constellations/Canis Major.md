---
tags: [constellation]
---
# Canis Major

The great dog, led by Sirius.

Bright stars: [[Sirius]]

Best in the [[Winter sky]].

Back to the [[Sky atlas]].
