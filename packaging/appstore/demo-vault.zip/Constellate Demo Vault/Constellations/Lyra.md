---
tags: [constellation]
---
# Lyra

A small lyre with Vega and the Ring Nebula.

Bright stars: [[Vega]]

Worth finding: [[Ring Nebula]]

Best in the [[Summer sky]].

Back to the [[Sky atlas]].
