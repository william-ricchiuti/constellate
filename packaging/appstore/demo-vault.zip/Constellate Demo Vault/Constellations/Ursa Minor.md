---
tags: [constellation]
---
# Ursa Minor

The little bear, with Polaris at the end of its tail.

Bright stars: [[Polaris]]

Back to the [[Sky atlas]].
