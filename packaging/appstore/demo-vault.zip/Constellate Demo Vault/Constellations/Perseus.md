---
tags: [constellation]
---
# Perseus

The hero, with Algol in his hand.

Bright stars: [[Algol]]

Worth finding: [[Double Cluster]]

Best in the [[Winter sky]], [[Autumn sky]].

Back to the [[Sky atlas]].
