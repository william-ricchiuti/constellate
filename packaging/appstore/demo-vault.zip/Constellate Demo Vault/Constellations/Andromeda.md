---
tags: [constellation]
---
# Andromeda

The chained princess, home of the nearest big galaxy.

Bright stars: [[Mirach]]

Worth finding: [[Andromeda Galaxy]]

Best in the [[Autumn sky]].

Back to the [[Sky atlas]].
