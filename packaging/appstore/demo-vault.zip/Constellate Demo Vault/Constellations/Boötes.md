---
tags: [constellation]
---
# Boötes

The herdsman, a kite shape with Arcturus at its tail.

Bright stars: [[Arcturus]]

Best in the [[Spring sky]].

Back to the [[Sky atlas]].
