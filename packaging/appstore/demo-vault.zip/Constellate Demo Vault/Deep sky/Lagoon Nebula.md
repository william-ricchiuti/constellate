---
tags: [deep-sky]
---
# Lagoon Nebula

A glowing cloud in the summer Milky Way. In [[Sagittarius]]. Try it with [[Binoculars]] first.
