---
tags: [deep-sky]
---
# Double Cluster

Two open clusters side by side. In [[Perseus]]. Try it with [[Binoculars]] first.
