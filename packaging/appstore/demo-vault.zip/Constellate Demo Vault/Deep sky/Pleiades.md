---
tags: [deep-sky]
---
# Pleiades

The Seven Sisters, a young open cluster. In [[Taurus]]. Try it with [[Binoculars]] first.
