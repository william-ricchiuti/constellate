---
tags: [deep-sky]
---
# Orion Nebula

A star nursery visible to the naked eye. In [[Orion]]. Try it with [[Binoculars]] first.
