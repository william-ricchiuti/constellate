---
tags: [deep-sky]
---
# Ring Nebula

A smoke ring left by a dying star. In [[Lyra]]. Try it with [[Binoculars]] first.
