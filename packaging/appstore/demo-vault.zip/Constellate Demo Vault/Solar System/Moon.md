---
tags: [moon]
---
# Moon

Best along the line between light and dark, not when full. Part of the [[Solar System]].
