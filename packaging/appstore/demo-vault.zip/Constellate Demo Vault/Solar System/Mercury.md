---
tags: [planet]
---
# Mercury

Never far from the Sun; look low after sunset. Part of the [[Solar System]].
