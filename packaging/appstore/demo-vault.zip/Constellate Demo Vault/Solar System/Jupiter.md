---
tags: [planet]
---
# Jupiter

Four moons show in binoculars. Part of the [[Solar System]].
