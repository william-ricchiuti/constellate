---
tags: [planet]
---
# Uranus

Just visible to the naked eye under a dark sky. Part of the [[Solar System]].
