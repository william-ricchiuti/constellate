---
tags: [planet]
---
# Venus

The brightest planet, the evening or morning star. Part of the [[Solar System]].
