---
tags: [planet]
---
# Mars

Red, and best when it is opposite the Sun. Part of the [[Solar System]].
