---
tags: [planet]
---
# Saturn

The rings show in any small telescope. Part of the [[Solar System]].
