---
tags: [season]
---
# Summer sky

- [[Lyra]]
- [[Cygnus]]
- [[Aquila]]
- [[Scorpius]]
- [[Sagittarius]]
- [[Summer Triangle]]
