---
tags: [season]
---
# Autumn sky

- [[Andromeda]]
- [[Cassiopeia]]
- [[Perseus]]
- [[Andromeda Galaxy]]
