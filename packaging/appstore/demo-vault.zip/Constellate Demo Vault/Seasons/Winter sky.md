---
tags: [season]
---
# Winter sky

- [[Orion]]
- [[Taurus]]
- [[Gemini]]
- [[Canis Major]]
- [[Perseus]]
- [[Winter Hexagon]]
