---
tags: [hub]
---
# Gear

- [[Binoculars]]: 10x50s: the best first instrument.
- [[Telescope]]: A small reflector on a simple mount.
- [[Star chart]]: A planisphere for the month, and an app as a backup.
- [[Red flashlight]]: Keeps the eyes dark-adapted.
- [[Dark site]]: Somewhere an hour from the city lights.
