---
tags: [hub]
---
# Start here

A small stargazing notebook, made to show what Constellate does with a notes folder.
Every note is a dot on the wallpaper and every link a line.

- [[Sky atlas]]: constellations, stars and deep-sky objects
- [[Solar System]]: the planets and the Moon
- [[Observing log]]: one note per night out
- [[Gear]]: what to take
