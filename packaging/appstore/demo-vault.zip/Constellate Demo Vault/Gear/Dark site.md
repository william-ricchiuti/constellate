---
tags: [gear]
---
# Dark site

Somewhere an hour from the city lights.
