---
tags: [gear]
---
# Telescope

A small reflector on a simple mount.
