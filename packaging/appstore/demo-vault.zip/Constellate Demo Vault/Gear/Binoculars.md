---
tags: [gear]
---
# Binoculars

10x50s: the best first instrument.
