---
tags: [gear]
---
# Red flashlight

Keeps the eyes dark-adapted.
