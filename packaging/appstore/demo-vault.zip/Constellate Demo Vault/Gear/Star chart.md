---
tags: [gear]
---
# Star chart

A planisphere for the month, and an app as a backup.
