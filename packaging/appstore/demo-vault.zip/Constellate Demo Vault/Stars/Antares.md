---
tags: [star]
---
# Antares

The red heart of the scorpion. In [[Scorpius]].
