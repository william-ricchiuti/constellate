---
tags: [star]
---
# Schedar

The brightest star of the W. In [[Cassiopeia]].
