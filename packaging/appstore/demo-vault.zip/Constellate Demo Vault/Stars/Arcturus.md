---
tags: [star]
---
# Arcturus

The brightest star north of the celestial equator. In [[Boötes]].
