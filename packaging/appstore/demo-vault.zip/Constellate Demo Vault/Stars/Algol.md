---
tags: [star]
---
# Algol

The demon star, an eclipsing binary that dims every few days. In [[Perseus]].
