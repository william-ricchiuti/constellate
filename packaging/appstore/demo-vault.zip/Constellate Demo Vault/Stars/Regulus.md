---
tags: [star]
---
# Regulus

The heart of the lion, close to the ecliptic. In [[Leo]].
