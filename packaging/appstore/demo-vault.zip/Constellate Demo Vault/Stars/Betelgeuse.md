---
tags: [star]
---
# Betelgeuse

A red supergiant on Orion's shoulder. In [[Orion]].
