---
tags: [star]
---
# Rigel

A blue supergiant at Orion's foot. In [[Orion]].
