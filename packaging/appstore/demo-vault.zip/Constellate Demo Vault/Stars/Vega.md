---
tags: [star]
---
# Vega

One of the brightest stars of the summer sky. In [[Lyra]].
