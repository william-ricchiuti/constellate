---
tags: [star]
---
# Deneb

The tail of the swan, very far away and very luminous. In [[Cygnus]].
