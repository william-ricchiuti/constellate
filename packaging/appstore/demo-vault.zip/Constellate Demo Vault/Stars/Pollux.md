---
tags: [star]
---
# Pollux

The brighter twin, an orange giant. In [[Gemini]].
