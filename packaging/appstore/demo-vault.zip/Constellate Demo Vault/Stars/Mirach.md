---
tags: [star]
---
# Mirach

A red giant; a guide star to the Andromeda Galaxy. In [[Andromeda]].
