---
tags: [star]
---
# Aldebaran

The orange eye of the bull. In [[Taurus]].
