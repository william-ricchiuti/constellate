---
tags: [star]
---
# Alpha Centauri

The nearest star system to the Sun. In [[Centaurus]].
