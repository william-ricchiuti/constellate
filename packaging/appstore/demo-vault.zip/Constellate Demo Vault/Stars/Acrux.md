---
tags: [star]
---
# Acrux

The foot of the Southern Cross. In [[Crux]].
