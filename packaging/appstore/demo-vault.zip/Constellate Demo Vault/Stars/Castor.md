---
tags: [star]
---
# Castor

One of the twins; a system of six stars. In [[Gemini]].
