---
tags: [star]
---
# Sirius

The brightest star in the night sky. In [[Canis Major]].
