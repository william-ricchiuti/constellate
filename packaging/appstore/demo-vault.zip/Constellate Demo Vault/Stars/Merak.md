---
tags: [star]
---
# Merak

The other pointer star; the line through both leads to Polaris. In [[Ursa Major]].
