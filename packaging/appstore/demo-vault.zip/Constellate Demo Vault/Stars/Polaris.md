---
tags: [star]
---
# Polaris

The North Star, almost exactly above the north pole. In [[Ursa Minor]].
