---
tags: [star]
---
# Dubhe

One of the two pointer stars of the Big Dipper. In [[Ursa Major]].
