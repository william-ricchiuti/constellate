---
tags: [star]
---
# Altair

A fast-spinning star in the eagle. In [[Aquila]].
